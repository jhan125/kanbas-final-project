import React from "react";

export default function ReduxExamples() {
  return(
    <div>
      <h2>Redux Examples</h2>
    </div>
  );
};
